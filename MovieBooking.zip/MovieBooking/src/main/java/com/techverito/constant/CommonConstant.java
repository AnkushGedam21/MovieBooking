package com.techverito.constant;

public class CommonConstant {
    public static final double SERVICE_TAX = 0.14;
    public static final double SWACHHBHARAT_CESS_TAX = 0.5;
    public static final double KRISHIKALYAN_CESS_TAX = 0.5;
}
