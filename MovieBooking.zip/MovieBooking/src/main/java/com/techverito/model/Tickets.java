package com.techverito.model;

public class Tickets {
}
