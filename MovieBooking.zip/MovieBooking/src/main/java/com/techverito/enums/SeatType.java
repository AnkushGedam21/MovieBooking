package com.techverito.enums;
public enum SeatType {
    PLATINUM,
    GOLD,
    SILVER
}